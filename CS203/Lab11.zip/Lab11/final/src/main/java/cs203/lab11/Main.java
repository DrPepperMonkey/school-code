package cs203.lab11;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}