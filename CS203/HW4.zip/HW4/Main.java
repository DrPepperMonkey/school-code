package CS203.HW4;

public class Main {
    

    public static void main(String[] args) {
        GUI gui = new GUI();
        gui.build();
    }
}
